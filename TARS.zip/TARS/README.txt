La carpeta \tars proviene de la página https://github.com/Ignacio-Perez/tars/tree/noetic. Realizado en ROS 1.

La carpeta \tars_sfm_planning proviene de la página https://github.com/Ignacio-Perez/tars_sfm_planning

Ambas carpetas han sido modificadas conforme se explica en el PDF del trabajo y su instalación es la misma que la indicada en las páginas webs anteriores.

El vídeo ruta_tars.mpp4 muestra el resultado de dichas modificaciones.