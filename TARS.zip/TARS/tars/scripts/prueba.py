#!/usr/bin/env python3
import rospy
from geometry_msgs.msg import PointStamped
from tars.srv import RobotGoalSrv

def clicked_point_callback(msg):
    try:
        rospy.wait_for_service('/tars/robot_goal', timeout=1.0)
        send_goal = rospy.ServiceProxy('/tars/robot_goal', RobotGoalSrv)
        
        # id must be a string
        send_goal("09", msg.point.x, msg.point.y)
        rospy.loginfo(f"Sent TARS to ({msg.point.x:.2f}, {msg.point.y:.2f})")

    except rospy.ServiceException as e:
        rospy.logerr(f"Service call failed: {e}")

rospy.init_node('clicked_point_to_tars_goal')
rospy.Subscriber('/clicked_point', PointStamped, clicked_point_callback)
rospy.loginfo("Click on the map in RViz to move TARS")
rospy.spin()